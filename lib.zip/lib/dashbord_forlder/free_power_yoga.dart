import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:jin_reflex_new/screens/utils/comman_app_bar.dart';
import 'package:url_launcher/url_launcher.dart';

/// =====================
/// MODELS (keep as is)
/// =====================
class PowerYogaResponse {
  final bool success;
  final String message;
  final List<PowerYoga> data;

  PowerYogaResponse({
    required this.success,
    required this.message,
    required this.data,
  });

  factory PowerYogaResponse.fromJson(Map<String, dynamic> json) {
    return PowerYogaResponse(
      success: json['success'] ?? false,
      message: json['message'] ?? "",
      data: (json['data'] as List).map((e) => PowerYoga.fromJson(e)).toList(),
    );
  }
}

class PowerYoga {
  final int id;
  final String heading;
  final List<YogaVideo> videos;

  PowerYoga({required this.id, required this.heading, required this.videos});

  factory PowerYoga.fromJson(Map<String, dynamic> json) {
    return PowerYoga(
      id: json['id'],
      heading: json['heading'] ?? "",
      videos:
          (json['videos'] as List).map((e) => YogaVideo.fromJson(e)).toList(),
    );
  }
}

class YogaVideo {
  final String title;
  final String youtubeLink;
  final String image;
  final String image_url;

  YogaVideo({
    required this.title,
    required this.youtubeLink,
    required this.image,
    required this.image_url,
  });

  factory YogaVideo.fromJson(Map<String, dynamic> json) {
    return YogaVideo(
      title: json['title'] ?? "",
      youtubeLink: json['youtube_link'] ?? "",
      image: json['image'] ?? "",
      image_url: json['image_url'] ?? "",
    );
  }
}

/// =====================
/// SCREEN
/// =====================
class PowerYogaScreen extends StatefulWidget {
  const PowerYogaScreen({super.key});

  @override
  State<PowerYogaScreen> createState() => _PowerYogaScreenState();
}

class _PowerYogaScreenState extends State<PowerYogaScreen> {
  bool isLoading = true;
  List<PowerYoga> yogaList = [];

  @override
  void initState() {
    super.initState();
    fetchPowerYogas();
  }

  /// =====================
  /// API CALL
  /// =====================
  Future<void> fetchPowerYogas() async {
    try {
      final response = await http.get(
        Uri.parse('https://admin.jinreflexology.in/api/power-yogas'),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        yogaList = (jsonData['data'] as List)
            .map((e) => PowerYoga.fromJson(e))
            .toList();
      }
    } catch (e) {
      debugPrint("API Error: $e");
    }

    setState(() => isLoading = false);
  }

  /// =====================
  /// GET YOUTUBE THUMBNAIL
  /// =====================
  String getYoutubeThumbnail(String url) {
    try {
      final uri = Uri.parse(url);
      String? videoId;

      // youtu.be/ID
      if (uri.host.contains("youtu.be")) {
        if (uri.pathSegments.isNotEmpty) {
          videoId = uri.pathSegments.first;
        }
      }
      // youtube.com/watch?v=ID
      else if (uri.host.contains("youtube.com")) {
        videoId = uri.queryParameters['v'];
      }

      if (videoId == null || videoId.isEmpty) {
        return "";
      }

      return "https://img.youtube.com/vi/$videoId/0.jpg";
    } catch (e) {
      debugPrint("Thumbnail Error: $e");
      return "";
    }
  }

  /// =====================
  /// OPEN YOUTUBE
  /// =====================
  Future<void> openYoutube(String url) async {
    try {
      final uri = Uri.parse(url);

      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        debugPrint("Cannot open: $url");
      }
    } catch (e) {
      debugPrint("Open Youtube Error: $e");
    }
  }

  /// =====================
  /// RESPONSIVE UI
  /// =====================
  @override
  Widget build(BuildContext context) {
    final isTablet = MediaQuery.of(context).size.width >= 600;
    final screenWidth = MediaQuery.of(context).size.width;
    final padding = isTablet ? 24.0 : 12.0;

    return Scaffold(
      appBar: CommonAppBar(title: "Power Yoga"),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: EdgeInsets.all(padding),
              itemCount: yogaList.length,
              itemBuilder: (context, index) {
                final yoga = yogaList[index];

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Heading with responsive font size
                    Text(
                      yoga.heading,
                      style: TextStyle(
                        fontSize: isTablet ? 22.0 : 18.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: isTablet ? 16.0 : 10.0),

                    // Videos grid/list based on screen size
                    isTablet
                        ? _buildTabletVideos(yoga.videos, screenWidth)
                        : _buildMobileVideos(yoga.videos),
                    
                    SizedBox(height: isTablet ? 24.0 : 20.0),
                  ],
                );
              },
            ),
    );
  }

  /// =====================
  /// TABLET LAYOUT (Grid View)
  /// =====================
  Widget _buildTabletVideos(List<YogaVideo> videos, double screenWidth) {
    // Calculate columns based on screen width
    final crossAxisCount = screenWidth >= 900 ? 3 : 2;
    final itemSpacing = 16.0;
    final runSpacing = 16.0;

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: crossAxisCount,
        crossAxisSpacing: itemSpacing,
        mainAxisSpacing: runSpacing,
        childAspectRatio: 1.1, // Better aspect ratio for tablets
      ),
      itemCount: videos.length,
      itemBuilder: (context, index) {
        final video = videos[index];
        final thumbnail = getYoutubeThumbnail(video.youtubeLink);

        return GestureDetector(
          onTap: () => openYoutube(video.youtubeLink),
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xfffff3d6),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: const Color(0xfff1cd8f),
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Video title with responsive font
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Text(
                    video.title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),

                // Thumbnail with play button
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12.0),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Thumbnail image
                          _buildThumbnailImage(video, true),
                          
                          // Play button overlay
                          Container(
                            width: 70,
                            height: 70,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.black.withOpacity(0.5),
                            ),
                            child: const Icon(
                              Icons.play_arrow,
                              size: 40,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 12),
              ],
            ),
          ),
        );
      },
    );
  }

  /// =====================
  /// MOBILE LAYOUT (List View)
  /// =====================
  Widget _buildMobileVideos(List<YogaVideo> videos) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: videos.length,
      itemBuilder: (context, index) {
        final video = videos[index];
        final thumbnail = getYoutubeThumbnail(video.youtubeLink);

        return GestureDetector(
          onTap: () => openYoutube(video.youtubeLink),
          child: Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xfffff3d6),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: const Color(0xfff1cd8f),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  video.title,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 10),

                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      // Thumbnail image
                      _buildThumbnailImage(video, false),
                      
                      // Play button overlay
                      Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.black.withOpacity(0.4),
                        ),
                        child: const Icon(
                          Icons.play_arrow,
                          size: 36,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// =====================
  /// REUSABLE THUMBNAIL IMAGE WIDGET
  /// =====================
  Widget _buildThumbnailImage(YogaVideo video, bool isTablet) {
    return Image.network(
      video.image_url.isNotEmpty ? video.image_url : getYoutubeThumbnail(video.youtubeLink),
      height: isTablet ? 180 : 200,
      width: double.infinity,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(
        height: isTablet ? 180 : 200,
        width: double.infinity,
        color: Colors.grey[300],
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.broken_image,
              size: 40,
              color: Colors.grey,
            ),
            const SizedBox(height: 8),
            Text(
              "Image not available",
              style: TextStyle(
                fontSize: isTablet ? 14 : 12,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
      loadingBuilder: (context, child, loadingProgress) {
        if (loadingProgress == null) return child;
        return Container(
          height: isTablet ? 180 : 200,
          width: double.infinity,
          color: Colors.grey[200],
          child: const Center(
            child: CircularProgressIndicator(),
          ),
        );
      },
    );
  }
}