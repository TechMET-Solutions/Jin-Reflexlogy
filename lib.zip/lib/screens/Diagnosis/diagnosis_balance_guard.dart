import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:jin_reflex_new/api_service/prefs/PreferencesKey.dart';
import 'package:jin_reflex_new/api_service/prefs/app_preference.dart';
import 'package:jin_reflex_new/screens/Diagnosis/diagnosis_payment_helper.dart';

Future<bool> ensureDiagnosisBalanceAvailable(BuildContext context) async {
  try {
    final therapistId = AppPreference().getString(PreferencesKey.userId);

    if (therapistId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Unable to verify balance. Please login again."),
          backgroundColor: Colors.red,
        ),
      );
      return false;
    }

    Future<int> fetchBalance() async {
      final response = await Dio().post(
        "https://jinreflexology.in/api1/new/getTherapistBalance.php",
        data: FormData.fromMap({"therapistId": therapistId}),
      );

      final data = response.data;
      return data["success"] == 1
          ? int.tryParse(data["balance"].toString()) ?? 0
          : 0;
    }

    int balance = await fetchBalance();

    if (balance <= 0) {
      final bool paid = await showDiagnosisPaymentPopup(context);
      if (!paid) {
        return false;
      }

      await Future.delayed(const Duration(milliseconds: 800));
      balance = await fetchBalance();

      if (balance <= 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              "Payment completed. Balance is updating, please try diagnosis again.",
            ),
            backgroundColor: Colors.orange,
          ),
        );
        return false;
      }
    }

    return true;
  } catch (_) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Could not check balance. Please try again."),
        backgroundColor: Colors.red,
      ),
    );
    return false;
  }
}
