import 'package:shared_preferences/shared_preferences.dart';

class WelcomeDialogPrefs {
  static const String keyName = 'welcome_name';
  static const String keyMobile = 'welcome_mobile';
  static const String keyEmail = 'welcome_email';
  static const String keyDealerId = 'welcome_dealer_id';
  static const String keyDealerCompleted = 'dealer_completed';

  static Future<bool> shouldShowDialog() async {
    final prefs = await SharedPreferences.getInstance();
    return !(prefs.getBool(keyDealerCompleted) ?? false);
  }

  static Future<void> saveSubmission({
    required String name,
    required String mobile,
    required String email,
    required String dealerId,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final normalizedDealerId = dealerId.trim();

    await prefs.setString(keyName, name.trim());
    await prefs.setString(keyMobile, mobile.trim());
    await prefs.setString(keyEmail, email.trim());
    await prefs.setString(keyDealerId, normalizedDealerId);
    await prefs.setBool(
      keyDealerCompleted,
      normalizedDealerId.isNotEmpty,
    );
  }

  static Future<Map<String, String>> getSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      keyName: prefs.getString(keyName) ?? '',
      keyMobile: prefs.getString(keyMobile) ?? '',
      keyEmail: prefs.getString(keyEmail) ?? '',
      keyDealerId: prefs.getString(keyDealerId) ?? '',
    };
  }
}
